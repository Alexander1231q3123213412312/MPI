#include<mpi.h>
#include<stdio.h>
#include<stdlib.h>
#include <iostream>
#include<math.h>
#include<ctime>
using namespace std;
int ProcNum;
int ProcRank;
int flag = 0;
int Size;
int* A; int* B; int* C; int* F;

//***********************************************************
void PrintMatrix(int* A, int n)
{
for (int i = 0; i < n * n; i++)
{
if (i % n == 0)
{
cout <<"\n";
}
cout <<A[i] << "\t";
}
cout <<"\n";
}
//----------------------------------------------------------—
void RandInit(int* pMatrix, int Size)
{
for (int i = 0; i < Size*Size; i++)
{
pMatrix[i] = rand() % 10;
}
}
//-----------------------------------------------—
void InitProcess(int*& A, int*& B, int*& C, int*& F, int& Size) {
MPI_Comm_size(MPI_COMM_WORLD, &ProcNum);
MPI_Comm_rank(MPI_COMM_WORLD, &ProcRank);
if (ProcRank == 0) {
do {
printf("\n--Square matrix multiplication--");
printf("\nPlease, enter matrix size: ");
scanf("%d", &Size);
if (Size < ProcNum)
printf("Matrix size is less than the number of processes! \n");
if (Size % ProcNum != 0)
printf("Matrix size should be dividable by the number of processes! \n");
} while ((Size < ProcNum) || (Size % ProcNum != 0));
}
if (Size < 10) flag = 1;
MPI_Bcast(&Size, 1, MPI_INT, 0, MPI_COMM_WORLD);

if (ProcRank == 0)
{
A = new int[Size * Size];
B = new int[Size * Size];
C = new int[Size * Size];
F = new int[Size * Size];
RandInit(A, Size); RandInit(B, Size); RandInit(C, Size);
}
}
//-----------------------------------------------—
void Flip(int*& C, int dim)
{
double temp = 0.0;
for (int i = 0; i < dim; i++)
{
for (int j = i + 1; j < dim; j++)
{
temp = C[i * dim + j];
C[i * dim + j] = C[j * dim + i];
C[j * dim + i] = temp;
}
}
}
//-----------------------------------------------—
void MatrixMultiplicationMPI(int*& A, int*& B, int*& C, int*& F, int& Size) {
int dim = Size;
int i, j, k, p, ind;
int temp;
MPI_Status Status;
int ProcPartSize = dim / ProcNum;
int ProcPartElem = ProcPartSize * dim;
int* bufA = new int[dim * ProcPartSize];
int* bufB = new int[dim * ProcPartSize];
int* bufC = new int[dim * ProcPartSize];
int* bufF = new int[dim * ProcPartSize];
int ProcPart = dim / ProcNum, part = ProcPart * dim;
if (ProcRank == 0)
{
Flip(C, Size);
}

MPI_Scatter(A, part, MPI_INT, bufA, part, MPI_INT, 0, MPI_COMM_WORLD);
MPI_Scatter(B, part, MPI_INT, bufB, part, MPI_INT, 0, MPI_COMM_WORLD);
MPI_Scatter(C, part, MPI_INT, bufC, part, MPI_INT, 0, MPI_COMM_WORLD);

temp = 0.0;
for (i = 0; i < ProcPartSize; i++)
{
for (j = 0; j < ProcPartSize; j++)
{
for (k = 0; k < dim; k++)
temp += (bufA[i * dim + k]+bufB[i*dim+k]) * bufC[j * dim + k];
bufF[i * dim + j + ProcPartSize * ProcRank] = temp;
temp = 0.0;
}
}

int NextProc; int PrevProc;
for (p = 1; p < ProcNum; p++)
{
NextProc = ProcRank + 1;
if (ProcRank == ProcNum - 1)
NextProc = 0;
PrevProc = ProcRank - 1;
if (ProcRank == 0)
PrevProc = ProcNum - 1;
MPI_Sendrecv_replace(bufC, part, MPI_INT, NextProc, 0, PrevProc, 0, MPI_COMM_WORLD, &Status);
temp = 0.0;
for (i = 0; i < ProcPartSize; i++)
{
for (j = 0; j < ProcPartSize; j++)
{
for (k = 0; k < dim; k++)
{
temp += (bufA[i * dim + k] + bufB[i * dim + k]) * bufC[j * dim + k];
}
if (ProcRank - p >= 0)
ind = ProcRank - p;
else
ind = (ProcNum - p + ProcRank);

bufF[i * dim + j + ind * ProcPartSize] = temp;
temp = 0.0;
}
}
}
MPI_Gather(bufF, ProcPartElem, MPI_INT, F, ProcPartElem, MPI_INT, 0, MPI_COMM_WORLD);

delete[]bufA;
delete[]bufB;
delete[]bufC;

}

//------------------------------------------------------—

int main(int argc, char* argv[])
{
srand(time(0));
double beg, end, serial, parallel = 0;
MPI_Init(&argc, &argv);
InitProcess(A, B, C, F, Size);
if (ProcRank == 0)
{
PrintMatrix(A, Size);
PrintMatrix(B, Size);
PrintMatrix(C, Size);
}
beg = MPI_Wtime();
MatrixMultiplicationMPI(A, B, C, F,Size);
end = MPI_Wtime(); parallel = end - beg;
if (ProcRank == 0)
{
printf("\n", &ProcNum);
printf("\n");
printf("\nTime of execution - Parallel calculation:\n");
printf("%7.4", parallel);
if (flag)
{
printf("\nMatrix F - Parallel calculation\n");
PrintMatrix(F,Size);
}
}
MPI_Finalize();
delete[] A; delete[] B; delete[] C; delete[] F;
}

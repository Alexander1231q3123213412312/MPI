#include <iostream>
#include <math.h>
#include <mpi.h>
using namespace std;

double f(double x)
{
return (1 / sqrt(x * x * x + 1));
}
double g(double x)
{
return (sin(x));
}
double I(double a, double b, int n, double y)
{
return ((b - a) / (2 * n) * y);
}

int main(int argc, char* argv[]) {
int n = 1000000000, rank, size;
double a = 0, b = 1,c=1,d=2, y = 0,z = 0, dy,dz,In1,t;
MPI_Status st;
MPI_Init(&argc, &argv);
MPI_Comm_rank(MPI_COMM_WORLD, &rank);
MPI_Comm_size(MPI_COMM_WORLD, &size);

if (rank == 0)
t = MPI_Wtime();

MPI_Barrier(MPI_COMM_WORLD);

dy = (b - a) / n;
dz = (d - c) / n;
y += f(a) + f(b);
z += g(c) + g(d);
for (int i = rank; i <= n; i+=size)
{
y += 2 * (f(a + dy * i));
z += 2 * (g(c + dz * i));
}
if (rank != 0)
{
MPI_Send(&y, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
MPI_Send(&z, 1, MPI_DOUBLE, 0, 1, MPI_COMM_WORLD);
}
if (rank == 0)
{
double Y, F = y,Z, G = z;
for (int i = 1; i < size; i++)
{
MPI_Recv(&Y, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, &st);
MPI_Recv(&Z, 1, MPI_DOUBLE, i, 1, MPI_COMM_WORLD, &st);
F += Y;
G += Z;
}
In1 = I(a, b, n, F)+ I(c, d, n, G);
t = MPI_Wtime() - t;
printf("Значение интеграла=%lf,\n время счёта=%lf c.\n",In1, t);
}

MPI_Finalize();
}
